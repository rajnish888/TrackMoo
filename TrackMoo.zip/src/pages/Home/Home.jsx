import React from 'react';

const Home = () => {
  return (
    <div className='px-64'>Home </div>
  );
};

export default Home;
